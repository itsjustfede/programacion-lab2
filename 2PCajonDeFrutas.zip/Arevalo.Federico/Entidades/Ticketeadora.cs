﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Entidades
{
    public static class Ticketeadora
    {
        public static bool ImprimirTicket(this Cajon<Platano> c, string path)
        {
            bool returnValue = true;

            try
            {
                StreamWriter sw = new StreamWriter(path, true);
                sw.Write("{0:G} -- PRECIO TOTAL: ", DateTime.Now);
                sw.WriteLine(c.PrecioTotal);
                sw.Close();
            }
            catch (Exception)
            {
                returnValue = false;
            }

            return returnValue;
        }

    }
}
