﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase08
{
    public class Equipo
    {
        #region ATRIBUTOS

        private short _cantidadDeJugadores;
        private List<Jugador> _lista;
        private string _nombre;

        #endregion

        #region METODOS

        public List<Jugador> GetJugadores()
        {
            return this._lista;
        }
        #endregion

        #region COSNSTRUCTORES

        private Equipo()
        {
            this._lista = new List<Jugador>();
            this._cantidadDeJugadores = 5;
        }
        public Equipo(short candtidadJugadores, string nombre)
            : this()
        {
            this._cantidadDeJugadores = candtidadJugadores;
            this._nombre = nombre;
        }

        #endregion

        #region SOBRECARGAS
        public static bool operator +(Equipo e, Jugador j)
        {
            bool returnValue = false;
            bool bandera = true;

            if (e._cantidadDeJugadores > e._lista.Count || e != null || j != null)
            {
                foreach (Jugador jugador in e._lista)
                {
                    if (jugador != j)
                        bandera = true;
                    else
                    {
                        bandera = false;
                        break;
                    }
                }

                if (bandera)
                {
                    e._lista.Add(j);
                    returnValue = true;
                }
            }
            return returnValue;
        }

        public static bool operator -(Equipo e, Jugador j)
        {
            bool returnValue = false;
            bool bandera = false;

            foreach (Jugador item in e._lista)
            {
                if (item == j)
                {
                    bandera = true;
                    break;
                }
            }

            if (bandera)
            {
                e._lista.Remove(j);
                returnValue = true;
            }


            return returnValue;
        }
        #endregion

    }
}
