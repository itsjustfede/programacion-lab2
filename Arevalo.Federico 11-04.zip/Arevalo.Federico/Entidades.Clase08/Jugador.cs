﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase08
{
    public class Jugador
    {

        #region ATRIBUTOS

        private long _dni;
        private string _nombre;
        private int _partidosJugados;
        private int _promedioGoles;
        private int _totalGoles;

        #endregion

        #region PROPIEDADES
        public long Dni
        {
            get
            {
                return this._dni;
            }
            set
            {
                this._dni = value;
            }

        }

        public string Nombre
        {
            get
            {
                return this._nombre;
            }
            set
            {
                this._nombre = value;
            }
        }

        public int PartidosJugados
        {
            get
            {
                return this._partidosJugados;
            }
            set
            {
                this._partidosJugados = value;
            }
        }

        public int TotalGoles
        {
            get
            {
                return this._totalGoles;
            }
            set
            {
                this._totalGoles = value;
            }
        }
        #endregion

        //METODOS


        public float GetPromedioGoles()
        {
            return this._promedioGoles;
        }

        public string MostrarDatos()
        {
            return "Nombre: " + this._nombre + "\n" + "DNI: " + this._dni + "\n" + "Partidos jugados: " + this._partidosJugados
                + "\n" + "Total goles: " + this._totalGoles + "\n" + "Promedio goles: " + this._promedioGoles + "\n";
        }

        //CONSTRUCTORES

        private Jugador()
        {
            this._dni = 0;
            this._nombre = "";
            this._partidosJugados = 0;
            this._totalGoles = 0;
            this._promedioGoles = 0;
        }

        public Jugador(string nombre, long dni)
            : this()
        {
            this._nombre = nombre;
            this._dni = dni;
        }

        public Jugador(string nombre, long dni, int totalGoles, int totalPartidos)
            : this(nombre, dni)
        {
            this._totalGoles = totalGoles;
            this._partidosJugados = totalPartidos;
        }

        //OPERADORES    

        public static bool operator ==(Jugador jugador1, Jugador jugador2)
        {
            return jugador1._nombre == jugador2._nombre &&
                    jugador1._dni == jugador2._dni;
        }

        public static bool operator !=(Jugador jugador1, Jugador jugador2)
        {
            return !(jugador1 == jugador2);
        }


    }

}
