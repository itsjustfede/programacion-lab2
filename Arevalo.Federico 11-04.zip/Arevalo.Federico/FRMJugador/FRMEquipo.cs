﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase08;

namespace FRMJugador
{
    public partial class FRMEquipo : Form
    {
        Equipo _equipo;

        private void Agregar()
        {
            this.lstMonitor.Items.Clear();

            foreach (Jugador item in this._equipo.GetJugadores())
            {
                this.lstMonitor.Items.Add(item.MostrarDatos());
            }
        }

        public FRMEquipo()
        {
            InitializeComponent();
        }

        private void lblNombre_Click(object sender, EventArgs e)
        {

        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string nombre = this.txtNombre.Text;
            short cantidadJugadores = short.Parse(this.txtCantidadJugadores.Text);

            this._equipo = new Equipo(cantidadJugadores, nombre);

            this.txtCantidadJugadores.Enabled = false;
            this.txtNombre.Enabled = false;

            this.btnAceptar.Visible = false;
            this.btnCancelar.Visible = false;

            this.btnMas.Visible = true;
            this.btnModificar.Visible = true;
            this.btnMenos.Visible = true;
            this.lstMonitor.Visible = true;            
        }

        private void btnMas_Click(object sender, EventArgs e)
        {
            FRMJugador miFormulario = new FRMJugador(); //crea una instancia de frmjugador

            miFormulario.ShowDialog(); //lo muestra
            //miFormulario.DialogResult = System.Windows.Forms.DialogResult.OK;

            if (miFormulario.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                Jugador jugador;

                jugador = miFormulario.GetJugador();

                if (this._equipo + jugador)
                {
                    MessageBox.Show("Se agrego correctamente el jugador");
                    this.Agregar();
                }
                else
                    MessageBox.Show("No se pudo agregar el jugador");
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

        }

        private void lstMonitor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            int indice = this.lstMonitor.SelectedIndex;

            if (indice > -1)
            {
                //MessageBox.Show(this._equipo.GetJugadores()[indice].MostrarDatos());

                DialogResult resultado = MessageBox.Show(this._equipo.GetJugadores()[indice].MostrarDatos(), 
                    "Estas seguro que deseas eliminar a", MessageBoxButtons.OKCancel, MessageBoxIcon.Information, 
                    MessageBoxDefaultButton.Button2);

                if (resultado == System.Windows.Forms.DialogResult.OK)
                {
                    if (this._equipo - this._equipo.GetJugadores()[indice])
                    {
                        MessageBox.Show("Se elimino correctamente el jugador");
                        this.Agregar();
                    }
                    else
                        MessageBox.Show("No se pudo eliminar el jugador");
                }

            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

            int indice = this.lstMonitor.SelectedIndex;

            if (indice > -1)
            {
                FRMJugador miFormulario = new FRMJugador(this._equipo.GetJugadores()[indice]);

                miFormulario.ShowDialog();

                if (miFormulario.DialogResult == System.Windows.Forms.DialogResult.OK)
                {
                    this._equipo.GetJugadores()[indice] = miFormulario.GetJugador();
                    this.Agregar();
                }
            }
        }
    }
}
