﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase08;

namespace FRMJugador
{
    public partial class FRMJugador : Form
    {
        private Jugador _jugador;

        public Jugador GetJugador() 
        {
            return this._jugador;
        }

        public FRMJugador()
        {
            InitializeComponent();
        }

        //CONSTRUCTOR SOBRECARGADO

        public FRMJugador(Jugador j) : this()
        {
            this.txtDni.Text = j.Dni.ToString();
            this.txtGoles.Text = j.TotalGoles.ToString();
            this.txtNombre.Text = j.Nombre.ToString();
            this.txtPartidosJugados.Text = j.PartidosJugados.ToString();

            this.txtDni.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lblDni_Click(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            long dni = long.Parse(this.txtDni.Text);
            string nombre = this.txtNombre.Text;
            int partidosJugados = int.Parse(this.txtPartidosJugados.Text);
            int goles = int.Parse(this.txtGoles.Text);

            if (((object)(this._jugador)) == null)
            {
                this._jugador = new Jugador(nombre, dni, goles, partidosJugados);
                MessageBox.Show(this._jugador.MostrarDatos() + "\nJugador guardado con exito");
            }
            else
            {
                this._jugador.Nombre = this.txtNombre.Text;
                this._jugador.PartidosJugados = int.Parse(this.txtPartidosJugados.Text);
                this._jugador.TotalGoles = int.Parse(this.txtGoles.Text);
            }

            this.DialogResult = System.Windows.Forms.DialogResult.OK;

        }
    }
}
