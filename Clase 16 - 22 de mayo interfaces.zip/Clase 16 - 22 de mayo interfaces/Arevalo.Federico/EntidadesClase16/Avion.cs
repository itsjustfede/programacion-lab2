﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase16
{
    public class Avion : Vehiculo, IAFIP
    {
        protected double _velocidadMaxima;

        public Avion(double precio, double velMax)
            : base(precio)
        {
            this._velocidadMaxima = velMax;
        }

        public override void MostrarPrecio()
        {
            Console.WriteLine("PRECIO: {0:N}", this.Precio);
        }

        public double CalcularImpuesto()
        {
            return (this.Precio + ((this.Precio * 1.33) / 100));
        }

        public override double Precio
        {
            get
            {
                return base._precio;
            }
            set
            {
                base._precio = value;
            }
        }
    }
}
