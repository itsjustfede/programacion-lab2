﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase16
{
    public class Carreta : Vehiculo
    {
        public Carreta(double precio)
            : base(precio) { }

        public override double Precio
        {
            get
            {
                return base._precio;
            }
            set
            {
                base._precio = value;
            }
        }

        public override void MostrarPrecio()
        {
            Console.WriteLine("PRECIO: {0:N}", this.Precio);
        }
    }
}
