﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase16
{
    public class Deportivo : Auto, IAFIP
    {
        protected int _caballosDeFuerza;

        public Deportivo(double precio, string patente, int hp)
            : base(precio, patente)
        {
            this._caballosDeFuerza = hp;
        }

        public override string Patente
        {
            get
            {
                return base._patente;
            }
            set
            {
                base._patente = value;
            }
        }

        public override double Precio
        {
            get
            {
                return base._precio;
            }
            set
            {
                base._precio = value;
            }
        }

        public override void MostrarPrecio()
        {
            Console.WriteLine("PRECIO: {0:N}", this.Precio);
        }

        public override void MostrarPatente()
        {
            Console.WriteLine("PATENTE: " + this.Patente);
        }

        public double CalcularImpuesto()
        {
            return (this.Precio + ((this.Precio * 1.28) / 100));
        }
    }
}
