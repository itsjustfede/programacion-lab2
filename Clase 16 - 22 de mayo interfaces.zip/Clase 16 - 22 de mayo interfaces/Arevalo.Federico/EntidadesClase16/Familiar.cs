﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase16
{
    public class Familiar : Auto
    {
        private int _cantidadDeAsientos;

        public Familiar(double precio, string patente, int cantidadDeAsientos)
            : base(precio, patente)
        {
            this._cantidadDeAsientos = cantidadDeAsientos;
        }

        public override void MostrarPrecio()
        {
            Console.WriteLine("PRECIO: {0:N}", this.Precio);
        }

        public override void MostrarPatente()
        {
            Console.WriteLine("PATENTE: " + this.Patente);
        }

        public override string Patente
        {
            get
            {
                return base._patente;
            }
            set
            {
                base._patente = value;
            }
        }

        public override double Precio
        {
            get
            {
                return base._precio;
            }
            set
            {
                base._precio = value;
            }
        }
    }
}
