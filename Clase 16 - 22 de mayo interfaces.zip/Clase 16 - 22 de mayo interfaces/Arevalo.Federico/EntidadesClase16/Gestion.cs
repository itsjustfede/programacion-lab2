﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase16
{
    static class Gestion
    {
        public static double MostrarImpuestoNacional(IAFIP bienPunible) //AVION + privado o comercial - DEPORTIVO
        {
            return bienPunible.CalcularImpuesto();
        }
    }
}
