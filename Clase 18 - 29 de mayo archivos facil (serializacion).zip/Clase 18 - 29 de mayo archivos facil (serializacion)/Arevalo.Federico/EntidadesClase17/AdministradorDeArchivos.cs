﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase17
{
    public static class AdministradorDeArchivos
    {
        public static bool Escribir(string path, string escribir, bool modo)
        {
            bool returnValue = true;

            try
            {
                StreamWriter sw = new StreamWriter(path, modo);
                sw.WriteLine(escribir);
                sw.Close();
            }
            catch (Exception)
            {
                returnValue = false;
                throw;
            }
            

            return returnValue;
        }

        public static bool Leer(string path, out string leido)
        {
            bool returnValue = true;
            string texto;
            leido = "";

            try
            {
                StreamReader sr = new StreamReader(path);

                while ((texto = sr.ReadLine()) != null) 
                {
                    leido += texto;
                    leido += "\n";
                }                
                //leido.Substring(

                sr.Close();
            }
            catch (Exception)
            {
                returnValue = false;
                throw;
            }

            return returnValue;
        }
    }
}
