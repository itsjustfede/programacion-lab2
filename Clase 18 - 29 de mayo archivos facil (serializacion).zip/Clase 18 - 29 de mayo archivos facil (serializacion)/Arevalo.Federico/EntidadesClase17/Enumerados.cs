﻿public enum EPuesto
{
    Aquero,
    Defensa,
    Medio,
    Delantero
}