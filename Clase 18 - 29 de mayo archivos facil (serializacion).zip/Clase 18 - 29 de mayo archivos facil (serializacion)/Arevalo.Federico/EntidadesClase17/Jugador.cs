﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Agrego el namespace para implementar la serializacion
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
//Agrego el namespace para la clase XML
using System.Xml;
using System.Xml.Serialization;


namespace EntidadesClase17
{
    [Serializable] public class Jugador : ISerializableBinario, ISerializableXML
    {
        protected string _nombre;
        public string _apellido;
        protected EPuesto _puesto;

        public string Nombre { get { return this._nombre; } set { this._nombre = value; } }
        public string Apellido { get { return this._apellido; } }
        public EPuesto Puesto { get { return this._puesto; } }

        public Jugador()
        {
 
        }

        public Jugador(string nombre, string apellido, EPuesto puesto)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._puesto = puesto;
        }

        public override string ToString()
        {
            return this._nombre + "-" + this._apellido + "-" + this._puesto;
        }

        public static bool TraerUno(string path, Jugador j1, out Jugador j2)
        {
            bool returnValue = false;
            string cadenaDeJugadores;
            string[] arrayJugadores;
            string[] cadenas;
            j2 = null;

            if (AdministradorDeArchivos.Leer(path, out cadenaDeJugadores))
            {
                arrayJugadores = cadenaDeJugadores.Split('\n');

                foreach (string item in arrayJugadores)
                {
                    cadenas = item.Split('-');
                    cadenas[2].Trim();

                    if (cadenas[0] == j1.Nombre && 
                        cadenas[1] == j1.Apellido && 
                        cadenas[2] == j1.Puesto.ToString())
                    {
                        j2 = new Jugador(cadenas[0], cadenas[1], (EPuesto)Enum.Parse(typeof(EPuesto), cadenas[2]));
                        returnValue = true;
                        break;
                    }
                }
            }

            return returnValue;
        }

        void ISerializableBinario.Serializar()
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream fs = new FileStream("jugadores.dat", FileMode.Create);

            bf.Serialize(fs, this);

            fs.Close();
        }

        Jugador ISerializableBinario.Deserializar()
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream fs = new FileStream("jugadores.dat", FileMode.Open);

            Jugador j =(Jugador) bf.Deserialize(fs);

            fs.Close();

            return j;
        }

        void ISerializableXML.Serializar()
        {
            XmlTextWriter xmlT = new XmlTextWriter("jugadores.xml", Encoding.UTF8);

            XmlSerializer xmlS = new XmlSerializer(typeof(Jugador));

            xmlS.Serialize(xmlT, this);

            xmlT.Close();
        }

        Jugador ISerializableXML.Deserializar()
        {
            XmlTextReader xmlR = new XmlTextReader("jugadores.xml");
            XmlSerializer xmlS = new XmlSerializer(typeof(Jugador));

            Jugador j =(Jugador) xmlS.Deserialize(xmlR);

            xmlR.Close();

            return j;
        }
    }
}
