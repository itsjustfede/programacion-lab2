﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase18
{
    public class Alumno : Persona
    {
        public int _legajo;

        public Alumno() { }

        public Alumno(string nombre, string apellido, int dni, int legajo)
            : base(nombre, apellido, dni)
        {
            this._legajo = legajo;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(base.ToString());
            sb.Append(" - ");
            sb.Append("LEGAJO: ");
            sb.Append(this._legajo);

            return sb.ToString();
        }
    }
}
