﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase18
{
    public class Aula
    {
        private int _numero;
        private List<Persona> _lista;

        public List<Persona> Lista { get { return this._lista; } }

        private Aula()
        {
            this._lista = new List<Persona>();
        }

        public Aula(int numero)
            : this()
        {
            this._numero = numero;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (var item in this.Lista)
            {
                sb.AppendLine(item.ToString());
            }

            return sb.ToString();
        }
    }
}
