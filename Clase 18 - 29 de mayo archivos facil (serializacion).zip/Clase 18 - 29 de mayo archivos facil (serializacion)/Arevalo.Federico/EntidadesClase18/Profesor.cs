﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase18
{
    public class Profesor : Persona
    {
        protected string _titulo;

        public Profesor() { }

        public Profesor(string nombre, string apellido, int dni, string titulo)
            : base(nombre, apellido, dni)
        {
            this._titulo = titulo;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(base.ToString());
            sb.Append(" - ");
            sb.Append("TITULO: ");
            sb.Append(this._titulo);

            return sb.ToString();
        }
    }
}
