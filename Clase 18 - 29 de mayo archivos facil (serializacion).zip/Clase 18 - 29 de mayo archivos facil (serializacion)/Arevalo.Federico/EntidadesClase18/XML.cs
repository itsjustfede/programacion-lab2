﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace EntidadesClase18
{
    public class XML<T>
    {
        public bool GuardarXML(string path, T a)
        {
            bool returnValue = true;

            try
            {
                XmlTextWriter xmlT = new XmlTextWriter(path, Encoding.UTF8);

                XmlSerializer xmlS = new XmlSerializer(typeof(T));

                xmlS.Serialize(xmlT, a);

                xmlT.Close();
            }
            catch (Exception)
            {
                returnValue = false;
            }

            return returnValue;
        }

        public bool LeerXML(string path, out T a)
        {
            a = default(T);

            bool returnValue = true;

            try
            {
                XmlTextReader xmlR = new XmlTextReader(path);
                XmlSerializer xmlS = new XmlSerializer(typeof(Alumno));

                a = (T)xmlS.Deserialize(xmlR);

                xmlR.Close();
            }
            catch (Exception)
            {
                returnValue = false;
            }

            return returnValue;
        }
    }
}
