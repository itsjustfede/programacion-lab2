﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntidadesClase17;

namespace FrmJugador
{
    public partial class FrmJugador : Form
    {
        public FrmJugador()
        {
            InitializeComponent();
            foreach (EPuesto item in Enum.GetValues(typeof(EPuesto)))
            {
                this.cmbPuesto.Items.Add(item);
            }
            this.cmbPuesto.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbPuesto.SelectedItem = EPuesto.Defensa;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cmbPuesto_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string nombre = this.txtNombre.Text;
            string apellido = this.txtApellido.Text;
            EPuesto puesto =(EPuesto) this.cmbPuesto.SelectedItem;

            Jugador nuevoJugador = new Jugador(nombre, apellido, puesto);

            //--------RUTA HARDCODEADA--------------

            //MessageBox.Show(nuevoJugador.ToString());

            //StreamWriter sw = new StreamWriter(@"D:\jugador.txt", true);
            //sw.WriteLine(nuevoJugador.ToString());
            //sw.Close();

            //StreamReader sr = new StreamReader(@"D:\jugador.txt");
            //string msj;

            //while ((msj = sr.ReadLine()) != null)
            //{
            //    MessageBox.Show(msj);
            //}
            //sr.Close();

            //--------USAMOS PATH DE WINDOWS----------

            //string linea;
            //string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            //path += "\\jugadores.txt";


            //AdministradorDeArchivos.Escribir(@"C:\Users\alumno\Desktop\jugadores.txt", nuevoJugador.ToString(), true);
            ////AdministradorDeArchivos.Leer(@"C:\Users\alumno\Desktop\jugadores.txt", out linea);

            //AdministradorDeArchivos.Escribir(path, nuevoJugador.ToString(), true);
            //AdministradorDeArchivos.Leer(path, out linea);

            //MessageBox.Show(linea);
            
            //GUARDAMOS EN LA DIRECCION QUE QUERRAMOS

            string linea2;
            string[] path2;

            if (this.saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                path2 = this.saveFileDialog1.FileNames;

                AdministradorDeArchivos.Escribir(path2[0], nuevoJugador.ToString(), true);
                AdministradorDeArchivos.Leer(path2[0], out linea2);

                MessageBox.Show(linea2); 
            }
            
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void btnTraer_Click(object sender, EventArgs e)
        {
            string nombre = this.txtNombre.Text;
            string apellido = this.txtApellido.Text;
            EPuesto puesto =(EPuesto) this.cmbPuesto.SelectedItem;

            Jugador actualJuagador = new Jugador(nombre, apellido, puesto);

            Jugador nuevoJugador;

            string[] path;
            path = this.saveFileDialog1.FileNames;

            if (Jugador.TraerUno(path[0], actualJuagador, out nuevoJugador))
            {
                this.txtNombre.Text = "";
                this.txtApellido.Text = "";
                this.cmbPuesto.Text = "";

                MessageBox.Show("Jugador encontrado");

                this.txtNombre.Text = nuevoJugador.Nombre;
                this.txtApellido.Text = nuevoJugador.Apellido;
                this.cmbPuesto.Text = nuevoJugador.Puesto.ToString();
            }
            else
                MessageBox.Show("No se encontro el jugador");
        }

        private void btnSerializar_Click(object sender, EventArgs e)
        {
            string nombre = this.txtNombre.Text;
            string apellido = this.txtApellido.Text;
            EPuesto puesto = (EPuesto)this.cmbPuesto.SelectedItem;

            Jugador nuevoJugador = new Jugador(nombre, apellido, puesto);

            ((ISerializableBinario)nuevoJugador).Serializar();
        }

        private void btnDeserializar_Click(object sender, EventArgs e)
        {
            Jugador nuevoJugador = new Jugador("Marcos", "Rodriguez", EPuesto.Medio);

            Jugador jugadorRecuperado = ((ISerializableBinario)nuevoJugador).Deserializar();

            this.txtNombre.Text = jugadorRecuperado.Nombre;
            this.txtApellido.Text = jugadorRecuperado.Apellido;
            this.cmbPuesto.Text = jugadorRecuperado.Puesto.ToString();
        }

        private void btnSerializarXML_Click(object sender, EventArgs e)
        {
            string nombre = this.txtNombre.Text;
            string apellido = this.txtApellido.Text;
            EPuesto puesto = (EPuesto)this.cmbPuesto.SelectedItem;

            Jugador nuevoJugador = new Jugador(nombre, apellido, puesto);

            ((ISerializableXML)nuevoJugador).Serializar();
        }

        private void btnDeserializarXML_Click(object sender, EventArgs e)
        {
            Jugador nuevoJugador = new Jugador("Marcos", "Rodriguez", EPuesto.Medio);

            Jugador jugadorRecuperado = ((ISerializableXML)nuevoJugador).Deserializar();

            this.txtNombre.Text = jugadorRecuperado.Nombre;
            this.txtApellido.Text = jugadorRecuperado.Apellido;
            this.cmbPuesto.Text = jugadorRecuperado.Puesto.ToString();
        }
    }
}
