﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesClase18;
using System.Xml;
using System.Xml.Serialization;

namespace TestEntidadesClase18
{
    class Program
    {
        static void Main(string[] args)
        {
            Aula aula = new Aula(28);

            XML<Alumno> xmlA = new XML<Alumno>();
            XML<Persona> xmlP = new XML<Persona>();
            XML<List<Alumno>> listaXML = new XML<List<Alumno>>();
            XML<List<Persona>> listaPersonasXML = new XML<List<Persona>>();
            XML<Aula> xmlAula = new XML<Aula>();

            List<Alumno> listaAlumnos = new List<Alumno>();
            List<Persona> listaPersona = new List<Persona>();

            Alumno a1 = new Alumno("Federico", "Arevalo", 123, 1);
            Alumno a2 = new Alumno("Marcos", "Meriggi", 124, 2);
            Alumno a3 = new Alumno("Facundo", "Meriggi", 125, 3);
            Alumno a4 = new Alumno("Nahuel", "Ibañez", 126, 4);

            Profesor p1 = new Profesor("Cristian", "Baus", 128, "Licenciado");

            aula.Lista.Add(a1);
            aula.Lista.Add(a2);
            aula.Lista.Add(a3);
            aula.Lista.Add(a4);
            aula.Lista.Add(p1);

            //Console.WriteLine(aula.ToString());

            //xmlA.GuardarXML("alumnos.xml", a1);
            //xmlP.GuardarXML("profesor.xml", p1);

            //listaAlumnos.Add(a1);
            //listaAlumnos.Add(a2);
            //listaAlumnos.Add(a3);
            //listaAlumnos.Add(a4);

            //listaXML.GuardarXML("lista.xml", listaAlumnos);

            listaPersona.Add(a1);
            listaPersona.Add(a2);
            listaPersona.Add(a3);
            listaPersona.Add(a4);
            listaPersona.Add(p1);

            listaPersonasXML.GuardarXML("listaPersonas.xml", listaPersona);

            if (xmlAula.GuardarXML("ListaAula.xml", aula))
                Console.WriteLine("Se guardo");

            //if (Program.GuardarXML("alumnos.xml", a1))
            //    Console.WriteLine("Se serializó");
            //else
            //    Console.WriteLine("No se pudo serializar");

            Console.ReadLine();
        }

        static bool GuardarXML(string path, Alumno a)
        {
            bool returnValue = true;

            try
            {
                XmlTextWriter xmlT = new XmlTextWriter(path, Encoding.UTF8);

                XmlSerializer xmlS = new XmlSerializer(typeof(Alumno));

                xmlS.Serialize(xmlT, a);

                xmlT.Close();
            }
            catch (Exception)
            {
                returnValue = false;
            }

            return returnValue;
        }

        static bool LeerXML(string path, out Alumno a)
        {
            a = null;
            bool returnValue = true;

            try
            {
                XmlTextReader xmlR = new XmlTextReader(path);
                XmlSerializer xmlS = new XmlSerializer(typeof(Alumno));

                a = (Alumno)xmlS.Deserialize(xmlR);

                xmlR.Close();
            }
            catch (Exception)
            {
                returnValue = false;
            }

            return returnValue;
        }
    }
}
