﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace Entidades30_5
{
    public class Persona
    {
        private string _nombre;
        private string _apellido;
        private int _edad;
        private int _id;

        public string Nombre { get { return this._nombre; }  set {this._nombre=value;}}
        public string Apellido { get {return this._apellido;}  set {this._apellido=value;}}
        public int Edad { get {return this._edad;}  set {this._edad=value;}}
        public int Id { get {return this._id;}}


        public Persona(string nombre, string apellido, int edad)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._edad = edad;
        }

        public Persona(int id, string nombre, string apellido, int edad) 
            : this(nombre,apellido,edad)

        {
            this._id = id;
        }

        public static List<Persona> TraerTodos()
        {
            List<Persona> per = new List<Persona>();
            //el namespace properties se crea cuando guardo la value en setting//
            SqlConnection baseDeDato = new SqlConnection(Properties.Settings.Default.conexion);
            //abre la conexion//
            baseDeDato.Open();
            //configo para poder pasarle comandos a la base de datos//
            SqlCommand comando = new SqlCommand("SELECT [id],[nombre],[apellido],[edad] FROM [Padron].[dbo].[Personas]", baseDeDato);
            //el sqldatareader no se puede instanciar , siempre le pasa el valor el execute reader//
            //es un objeto de solo lectura y de avance , es decir cada vez que lee algo lo elimina y pasa al siguiente//
            SqlDataReader lectura = comando.ExecuteReader();
            while (lectura.Read())
            {
               // lectura[0].ToString();//me traeria solo el nombre. siempre devuelve un obj porque puede ser cualq tipo de dato//
               // lectura["id"];//otra manera de devolver un valor//
                per.Add(new Persona(int.Parse(lectura[0].ToString()), lectura[1].ToString(),lectura[2].ToString(),int.Parse(lectura[3].ToString())));
            }

            lectura.Close();
            baseDeDato.Close();
           
            return per;
        }

        public override string ToString()
        {

            return this.Id + "--" + this.Nombre + "--" + this.Apellido + "--" + this.Edad + "\n"; 
        }

        public bool Agregar()
        {
            bool returnValue = true;

            try
            {
                SqlConnection sqlConexion = new SqlConnection(Properties.Settings.Default.conexion);

                SqlCommand sqlComand = new SqlCommand("insert into Personas (nombre,apellido,edad) values ('" + this.Nombre + "','" +
                         this.Apellido + "'," + this.Edad + ")"
                           , sqlConexion);
                sqlConexion.Open();

                sqlComand.ExecuteNonQuery();

                sqlConexion.Close();
            }
            catch (Exception)
            {
                returnValue = false;
            }          

            return returnValue;
        }

        public static bool Borrar(Persona p)
        {
            bool returnValue = true;

            try
            {
                SqlConnection sqlConexion = new SqlConnection(Properties.Settings.Default.conexion);

                SqlCommand sqlComand = new SqlCommand("delete from Personas where id="+p._id, sqlConexion);
                sqlConexion.Open();

                sqlComand.ExecuteNonQuery();

                sqlConexion.Close();
            }
            catch (Exception)
            {
                returnValue = false;
            }

            return returnValue;
        }

        public bool Modificar()
        {
            bool returnValue = true;

            try
            {
                SqlConnection sqlConexion = new SqlConnection(Properties.Settings.Default.conexion);

                SqlCommand sqlComand = new SqlCommand("update personas set nombre='"+this.Nombre+"',apellido='"+
                           this.Apellido+"',edad="+this.Edad+" where id="+this.Id+"", sqlConexion);
                sqlConexion.Open();

                sqlComand.ExecuteNonQuery();

                sqlConexion.Close();
            }
            catch (Exception)
            {
                returnValue = false;
            }

            return returnValue;
        }

        public static Persona TraerTodos(int id)
        {            
            SqlConnection sqlConexion = new SqlConnection(Properties.Settings.Default.conexion);
            
            sqlConexion.Open();
            
            SqlCommand sqlComand = new SqlCommand("SELECT [id],[nombre],[apellido],[edad] FROM [Padron].[dbo].[Personas] where id="+id, sqlConexion);
            
            SqlDataReader lectura = sqlComand.ExecuteReader();

            lectura.Read();

            Persona per = new Persona(int.Parse(lectura[0].ToString()), lectura[1].ToString(), lectura[2].ToString(), int.Parse(lectura[3].ToString()));
           
            lectura.Close();

            sqlConexion.Close();

            return per;
 
        }

        public static DataTable TraerTodosTabla()
        {
            DataTable dt = new DataTable("Personas");

            SqlConnection sqlConexion = new SqlConnection(Properties.Settings.Default.conexion);

            sqlConexion.Open();

            SqlCommand sqlComand = new SqlCommand("SELECT [id],[nombre],[apellido],[edad] FROM [Padron].[dbo].[Personas]", sqlConexion);

            SqlDataReader reader = sqlComand.ExecuteReader();

            dt.Load(reader);

            reader.Close();

            sqlConexion.Close();

            return dt; 
        }
            
    }
}
