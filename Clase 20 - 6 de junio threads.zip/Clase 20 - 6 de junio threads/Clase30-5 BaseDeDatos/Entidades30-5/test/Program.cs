﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades30_5;
using System.Data;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            //foreach (Persona per in Persona.TraerTodos())
            //        Console.WriteLine(per.ToString());
            
            //Persona p1 = new Persona(7,"Mati", "Quiroga", 24);

            ////Agregar

            //if (p1.Agregar())
            //    Console.WriteLine("---------Se agrego correctamente---------\n");
            //else
            //    Console.WriteLine("---------No se agrego--------------------\n");

            //foreach (Persona per in Persona.TraerTodos())
            //    Console.WriteLine(per.ToString());

            //Console.ReadLine();

            ////Borrar

            //if (Persona.Borrar(p1))
            //    Console.WriteLine("---------Se borro correctamente----------\n");
            //else
            //    Console.WriteLine("---------No se borro--------------------\n");

            //foreach (Persona per in Persona.TraerTodos())
            //{
            //    if (per.Id > 6)
            //        Persona.Borrar(per);

            //    Console.WriteLine(per.ToString());
            //}

            ////Modificar

            //if (p1.Modificar())
            //    Console.WriteLine("---------Se modifico correctamente---------\n");
            //else
            //    Console.WriteLine("---------No se modifico--------------------\n");

            //foreach (Persona per in Persona.TraerTodos())
            //    Console.WriteLine(per.ToString()); 

            //Console.WriteLine(Persona.TraerTodos(6));

            DataTable dt = Persona.TraerTodosTabla();

            foreach (DataRow item in dt.Rows)
            {
                Console.WriteLine(item[0].ToString()+"\t"+
                                  item[1].ToString()+"\t"+
                                  item[2].ToString());
            }
            Console.ReadLine();
        }
    }
}
