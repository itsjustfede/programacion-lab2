﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades30_5;
namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            foreach (Persona per in Persona.TraerTodos())
            {
                Console.WriteLine(per.ToString());
            }

            Persona p1 = new Persona("Federico", "Arevalo", 20);

            if (p1.Agregar())
            {
                Console.WriteLine("\nSe agregò correctamente\n");
            }
            else
            {
                Console.WriteLine("\nNo se agregò\n");
            }

            foreach (Persona per in Persona.TraerTodos())
            {
                Console.WriteLine(per.ToString());
            }

            Console.ReadLine();
        }
    }
}
