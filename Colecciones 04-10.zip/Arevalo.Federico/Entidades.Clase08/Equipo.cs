﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase08
{
    public class Equipo
    {
        private short _cantidadDeJugadores;
        private List<Jugador> _lista;
        private string _nombre;


        public List<Jugador> GetJugadores()
        {
            return this._lista;
        }

        private Equipo()
        {
            this._lista = new List<Jugador>();
            this._cantidadDeJugadores = 5;
        }
        public Equipo(short candtidadJugadores, string nombre)
            : this()
        {
            this._cantidadDeJugadores = candtidadJugadores;
            this._nombre = nombre;
        }

        public static bool operator + (Equipo e, Jugador j)
        {
            bool returnValue = false;
            bool bandera = true;

            if (e._cantidadDeJugadores > e._lista.Count)
            {
                foreach (Jugador jugador in e._lista)
                {
                    if (jugador != j)
                        bandera = true;
                    else
                    {
                        bandera = false;
                        break;
                    }
                }

                if (bandera)
                {       
                    e._lista.Add(j);
                    returnValue = true;
                }
            }
            return returnValue;
        }


    }
}
