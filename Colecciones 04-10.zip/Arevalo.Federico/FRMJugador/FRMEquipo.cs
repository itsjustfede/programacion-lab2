﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase08;

namespace FRMJugador
{
    public partial class FRMEquipo : Form
    {
        Equipo _equipo;

        public FRMEquipo()
        {
            InitializeComponent();
        }

        private void lblNombre_Click(object sender, EventArgs e)
        {

        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string nombre = this.txtNombre.Text;
            short cantidadJugadores = short.Parse(this.txtCantidadJugadores.Text);

            this._equipo = new Equipo(cantidadJugadores, nombre);

            this.txtCantidadJugadores.Enabled = false;
            this.txtNombre.Enabled = false;

            this.btnAceptar.Visible = false;
            this.btnCancelar.Visible = false;

            this.btnMas.Visible = true;
            this.lstMonitor.Visible = true;

        }
    }
}
