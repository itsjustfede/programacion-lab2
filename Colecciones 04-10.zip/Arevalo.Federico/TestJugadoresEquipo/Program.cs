﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Clase08;

namespace TestJugadoresEquipo
{
    class Program
    {
        static void Main(string[] args)
        {
            Equipo team = new Equipo(1, "Real Madrid");

            Jugador j1 = new Jugador("Ronaldo", 123);
            Jugador j2 = new Jugador("Bale", 124);
            Jugador j3 = new Jugador("Marcelo", 125);
            Jugador j4 = new Jugador("Marcelo", 125);

            Console.WriteLine(j1.MostrarDatos());

            Console.WriteLine(j2.MostrarDatos());

            Console.WriteLine(j3.MostrarDatos());

            if (team + j3)
                Console.WriteLine("\n\nfunca");


            if (!(team + j2))
                Console.WriteLine("\n\nfunca re bien");

            Console.ReadLine();
        }
    }
}
