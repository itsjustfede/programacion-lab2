﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase14
{
    public class ColectoraDeNumeros
    {
        protected List<Numero> _numeros;

        public ETipoNumero Tipo { get; set; } //get y set con ; son las propiedades autodefinidas

        private ColectoraDeNumeros()
        {
            this._numeros = new List<Numero>();
        }

        public ColectoraDeNumeros(ETipoNumero tipo)
        {
            this.Tipo = tipo;
        }

        public static bool operator ==(ColectoraDeNumeros c, Numero n)
        {
            bool returnValue = false;

            foreach (Numero item in c._numeros)
            {
                if (item.MiNumero == n.MiNumero)
                {
                    returnValue = true;
                    break; 
                }    
            }
            return returnValue;
        }

        public static bool operator !=(ColectoraDeNumeros c, Numero n)
        {
            return !(c == n);
        }

        public static ColectoraDeNumeros operator +(ColectoraDeNumeros c, Numero n)
        {

            if (Verificadora.VerificarNumero(c.Tipo, n))
                c._numeros.Add(n);
            else
                throw new Exception("El tipo " + c.Tipo + " no esta admitido");
            return c;
        }

        public static ColectoraDeNumeros operator -(ColectoraDeNumeros c, Numero n)
        {
            try
            {
                if (c == n)
                    c._numeros.Remove(n);
            }
            catch (Exception)
            {
                throw new Exception("El numero que quiere remover no existe\n" + c.ToString());
            }
            return c;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("----------------");
            sb.AppendLine("LISTA DE NUMEROS");
            sb.AppendFormat("TIPO: {0}", this.Tipo);
            sb.AppendLine("VALORES");
            sb.AppendLine();

            foreach (Numero item in this._numeros)
            {
                sb.AppendFormat("{0}", item.MiNumero);
                sb.AppendLine();
            }

            sb.AppendLine("----------------");

            return sb.ToString();
        }



    }
}
