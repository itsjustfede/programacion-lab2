﻿public enum ETipoNumero
{
    Par, Impar, Positivo, Negativo, Cero
}