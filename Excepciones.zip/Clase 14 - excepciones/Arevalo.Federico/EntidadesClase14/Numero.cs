﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase14
{
    public class Numero
    {
        protected int _numero;

        public int MiNumero { get { return this._numero; } }

        public Numero(int num)
        {
            this._numero = num;
        }

        public static Numero operator +(Numero num1, Numero num2)
        {
            num1._numero = num1._numero + num2._numero;

            return num1;
        }

        public static Numero operator -(Numero num1, Numero num2)
        {
            num1._numero = num1._numero - num2._numero;

            return num1;
        }

        public static Numero operator *(Numero num1, Numero num2)
        {
            num1._numero = num1._numero * num2._numero;

            return num1;
        }

        public static Numero operator /(Numero num1, Numero num2)
        {
            num1._numero = num1._numero * num2._numero;

            return num1;
        }

        public static bool Parse(string cadena, out Numero num)
        {
            bool returnValue = true;
            num = null;

            try
            {
                int numero = int.Parse(cadena);
                num = new Numero(numero);
            }
            catch (Exception)
            {
                returnValue = false;
            }

            return returnValue;
        }
    }
}
