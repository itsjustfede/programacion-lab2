﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase14
{
    public static class Verificadora
    {
        public static bool VerificarNumero(ETipoNumero tipo, Numero numero)
        {
            bool returnValue = false;

            switch (tipo)
            {
                case ETipoNumero.Par:
                    if (numero.MiNumero % 2 == 0)
                        returnValue = true;
                    break;
                case ETipoNumero.Impar:
                    if (numero.MiNumero % 2 != 0)
                        returnValue = true;
                    break;
                case ETipoNumero.Positivo:
                    if (numero.MiNumero > 0)
                        returnValue = true;
                    break;
                case ETipoNumero.Negativo:
                    if (numero.MiNumero < 0)
                        returnValue = true;
                    break;
                case ETipoNumero.Cero:
                    if (numero.MiNumero == 0)
                        returnValue = true;
                    break;
                default:
                    break;
            }

            return returnValue;
        }

    }
}
