﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesClase14;

namespace TestNumero
{
    class Program
    {
        static void Main(string[] args)
        {
            Numero num1;
            Numero num2 = new Numero(3);
            Numero num3 = new Numero(30);
            Numero num4 = new Numero(5);
            Numero num5 = new Numero(-1);
            Numero num6 = new Numero(0);

            Console.Write("Ingrese un numero: ");

            if (Numero.Parse(Console.ReadLine(), out num1))
                Console.WriteLine("El parseo funciono, muestro numero {0}", num1.MiNumero);
            else
                Console.WriteLine("No funciono perro");

            Console.ReadLine();
            Console.Clear();


            Console.ReadLine();
        }
    }
}
