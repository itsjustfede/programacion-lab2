﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EntidadesClase14;

namespace TestUnitario
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
